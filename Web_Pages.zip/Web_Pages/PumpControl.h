char PumpControl[] PROGMEM = R"=====(<!DOCTYPE html>
<!-- === Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <title>LogIn</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- ===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

     <!-- ===== CSS =====
    <link rel="stylesheet" href="style.css">
         
  <title>Login & Registration Form</title>--> 

  <style>
      /* ===== Google Font Import - Poformsins ===== */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body{
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #4070f4;
}

.container{
    position: relative;
    max-width: 430px;
    width: 100%;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    margin: 0 20px;
}

.container .forms{
    display: flex;
    align-items: center;
    height: 440px;
    width: 200%;
    transition: height 0.2s ease;
}


.container .form{
    width: 50%;
    padding: 30px;
    background-color: #fff;
    transition: margin-left 0.18s ease;
}

.container.active .login{
    margin-left: -50%;
    opacity: 0;
    transition: margin-left 0.18s ease, opacity 0.15s ease;
}

.container.active .forms{
    height: 600px;
}
.container .form .title{
    top: 0px;
    position: relative;
    font-size: 47px;
    font-weight: 600;
}

.form .title::before{
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 30px;
    background-color: #4070f4;
    border-radius: 25px;
}

input[type="checkbox"] {
  position: relative;
  width: 100px;
  height: 45px;
  background: #bdc3c7;
  -webkit-appearance: none;
  border-radius: 20px;
  outline: none;
  transition: .4s;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  margin-top: 40px;
}

input:checked[type="checkbox"] {
  background: #3498db;
}

input[type="checkbox"]::before {
  z-index: 2;
  position: absolute;
  content: "";
  left: 0;
  width: 46px;
  height: 43px;
  background: #fff;
  border-radius: 50%;
  transform: scale(1.1);
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  transition: .4s;
}

input:checked[type="checkbox"]::before {
  left: 60px;
}

.toggle {
  position: relative;
  display: inline;
}

label {
  position: absolute;
  color: #fff;
  font-weight: 600;
  font-size: 20px;
  pointer-events: none;
}

.onbtn {
  bottom: 15px;
  left: 15px;
}

.ofbtn {
  bottom: 15px;
  right: 14px;
  color: #34495e;
}

.form .text{
    color: #333;
    font-size: 14px;
}

.form a.text{
    color: #4070f4;
    text-decoration: none;
}
.form a:hover{
    text-decoration: underline;
}



.form .login-signup{
    margin-top: 200px;
    text-align: center;
}

  </style>

  <script>
      const container = document.querySelector(".container"),
      pwShowHide = document.querySelectorAll(".showHidePw"),
      pwFields = document.querySelectorAll(".password"),
      signUp = document.querySelector(".signup-link"),
      login = document.querySelector(".login-link");

    //   js code to show/hide password and change icon
    pwShowHide.forEach(eyeIcon =>{
        eyeIcon.addEventListener("click", ()=>{
            pwFields.forEach(pwField =>{
                if(pwField.type ==="password"){
                    pwField.type = "text";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye-slash", "uil-eye");
                    })
                }else{
                    pwField.type = "password";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye", "uil-eye-slash");
                    })
                }
            }) 
        })
    })

    // js code to appear signup and login form
    signUp.addEventListener("click", ( )=>{
        container.classList.add("active");
    });
    login.addEventListener("click", ( )=>{
        container.classList.remove("active");
    });

  </script>
</head>
<body>
    
    <div class="container">
        <div class="forms">
            <div class="form login">
                <span class="title">Water Pump</span>

                <form action="#">
                    <div class="toggle">
                        <input type="checkbox">
                        <label for="" class="onbtn">On</label>
                        <label for="" class="ofbtn">Off</label>
                      </div>
                </form>

                <div class="login-signup">
                    <span class="text">Go Back:
                        <a href="/SignIn" class="text signup-link">Log Out</a>
                    </span>
                </div>
            </div>

           
        </div>
    </div>

    <!--<script src="script.js"></script>-->

</body>
</html>
)=====";
