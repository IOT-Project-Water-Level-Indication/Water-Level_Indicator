char Signup[] PROGMEM = R"=====(<!DOCTYPE html>
<!-- Coding by CodingLab | www.codinglabweb.com-->
<html lang="en" dir="ltr">
  <head>
      <title>SignUp</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<title> Registration or Sign Up form in HTML CSS | CodingLab </title>
    <link rel="stylesheet" href="style.css">
    -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
<style>
@import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
body{
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #4070f4;
}
.wrapper{
  position: relative;
  max-width: 430px;
  width: 100%;
  background: #fff;
  padding: 34px;
  border-radius: 6px;
  box-shadow: 0 5px 10px rgba(0,0,0,0.2);
}
.wrapper h2{
  position: relative;
  font-size: 22px;
  font-weight: 600;
  color: #333;
}
.wrapper h2::before{
  content: '';
  position: absolute;
  left: 0;
  bottom: 0;
  height: 3px;
  width: 28px;
  border-radius: 12px;
  background: #4070f4;
}
.wrapper form{
  margin-top: 30px;
}
.wrapper form .input-box{
  height: 52px;
  margin: 18px 0;
}
form .input-box input{
  height: 100%;
  width: 100%;
  outline: none;
  padding: 0 15px;
  font-size: 17px;
  font-weight: 400;
  color: #333;
  border: 1.5px solid #C7BEBE;
  border-bottom-width: 2.5px;
  border-radius: 6px; 
  transition: all 0.3s ease;
}
.input-box input:focus,
.input-box input:valid{
  border-color: #4070f4;
}
form .policy{
  display: flex;
  align-items: center;
}
form h3{
  color: #707070;
  font-size: 14px;
  font-weight: 500;
  margin-left: 10px;
}
.input-box.button input{
  color: #fff;
  letter-spacing: 1px;
  border: none;
  background: #4070f4;
  cursor: pointer;
}
.input-box.button input:hover{
  background: #0e4bf1;
}
form .text h3{
 color: #333;
 width: 100%;
 text-align: center;
}
form .text h3 a{
  color: #4070f4;
  text-decoration: none;
}
form .text h3 a:hover{
  text-decoration: underline;
}

.alert{
    width: 100%;
    background: rgb(0, 255, 106);
    padding: 10px 20px;
    border-radius: 5px;
    text-align: center;
    font-size: 18px;
    font-weight: 900;
    display: none;
}

</style>

<script>
  const firebaseConfig = {
    apiKey: "AIzaSyAZEGxHwtFVyKkyG1x_NtwrPtdX-u6h2SQ",
    authDomain: "waterlevel-8897b.firebaseapp.com",
    databaseURL: "https://waterlevel-8897b-default-rtdb.firebaseio.com",
    projectId: "waterlevel-8897b",
    storageBucket: "waterlevel-8897b.appspot.com",
    messagingSenderId: "245847284272",
    appId: "1:245847284272:web:48e0ce44ef50329400abf5"
  };

  // initialize firebase
  firebase.initializeApp(firebaseConfig);
  
  // reference your database
  var newFormDB = firebase.database().ref("waterlevel");
  
  document.getElementById("waterlevel").addEventListener("submit", submitForm);
  
  function submitForm(e) {
    e.preventDefault();
  
    var name = getElementVal("name");
    var email = getElementVal("email");
    var password = getElementVal("password");
    var cp = getElementVal("cp");
  
    saveMessages(name, email, password, cp);
  
    //   enable alert
    document.querySelector(".alert").style.display = "block";
  
    //   remove the alert
    setTimeout(() => {
      document.querySelector(".alert").style.display = "none";
    }, 3000);
  
    //   reset the form
    document.getElementById("waterlevel").reset();
  }
  
  const saveMessages = (name, email, password, cp) => {
    var newForm = newFormDB.push();
  
    newForm.set({
      name: name,
      email: email,
      password: password,
      cp: cp,
    });
  };
  
  const getElementVal = (id) => {
    return document.getElementById(id).value;
  };




</script>



</head>
<body>
  <div class="wrapper">
    <h2>Registration</h2>
    <form action="#" id="waterlevel">

      <div class="alert">Your message sent</div>


      <div class="input-box">
        <input type="text" id="name" placeholder="Enter your name" required>
      </div>
      <div class="input-box">
        <input type="text" id="email" placeholder="Enter your email" required>
      </div>
      <div class="input-box">
        <input type="password" id="password" placeholder="Create password" required>
      </div>
      <div class="input-box">
        <input type="password" id="cp" placeholder="Confirm password" required>
      </div>
      
      <div class="input-box button">
        <input type="Submit" value="Register Now">
      </div>
      <div class="text">
        <h3>Already have an account? <a href="#">Login now</a></h3>
      </div>
    </form>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/firebase/7.14.1-0/firebase.js"></script>
  <script src="./main.js"></script>
</body>
</html>

)=====";
