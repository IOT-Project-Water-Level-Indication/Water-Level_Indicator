const firebaseConfig = {
    apiKey: "AIzaSyAZEGxHwtFVyKkyG1x_NtwrPtdX-u6h2SQ",
    authDomain: "waterlevel-8897b.firebaseapp.com",
    databaseURL: "https://waterlevel-8897b-default-rtdb.firebaseio.com",
    projectId: "waterlevel-8897b",
    storageBucket: "waterlevel-8897b.appspot.com",
    messagingSenderId: "245847284272",
    appId: "1:245847284272:web:48e0ce44ef50329400abf5"
  };

  // initialize firebase
  firebase.initializeApp(firebaseConfig);
  
  // reference your database
  var newFormDB = firebase.database().ref("waterlevel");
  
  document.getElementById("waterlevel").addEventListener("submit", submitForm);
  
  function submitForm(e) {
    e.preventDefault();
  
    var name = getElementVal("name");
    var email = getElementVal("email");
    var password = getElementVal("password");
    var cp = getElementVal("cp");
  
    saveMessages(name, email, password, cp);
  
    //   enable alert
    document.querySelector(".alert").style.display = "block";
  
    //   remove the alert
    setTimeout(() => {
      document.querySelector(".alert").style.display = "none";
    }, 3000);
  
    //   reset the form
    document.getElementById("waterlevel").reset();
  }
  
  const saveMessages = (name, email, password, cp) => {
    var newForm = newFormDB.push();
  
    newForm.set({
      name: name,
      email: email,
      password: password,
      cp: cp,
    });
  };
  
  const getElementVal = (id) => {
    return document.getElementById(id).value;
  };



